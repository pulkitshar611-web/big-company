$env:DATABASE_URL='mysql://root:@localhost:3306/big_company'
npx tsc
node dist/index.js
